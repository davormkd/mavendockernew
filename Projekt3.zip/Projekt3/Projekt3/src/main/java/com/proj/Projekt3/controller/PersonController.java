package com.proj.Projekt3.controller;

import org.springframework.web.bind.annotation.*;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

@RestController
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@RequestMapping("/persons")
public class PersonController {

	private static final Logger logger = LoggerFactory.getLogger(PersonController.class);
	private final List<Person> persons = new ArrayList<>();

	@GetMapping
	public List<Person> getPersons() {
		logger.info("Person info get");
		return persons;
	}

	@PostMapping
	public Person createPerson(@RequestBody Person person) {
		persons.add(person);
		logger.info("Person added");
		return person;
	}

	// Dummy Person-Klasse
	public static class Person {
		private int id;

		@JsonProperty("name")
		private String name;

		@JsonProperty("age")
		private int age;

		// Getter und Setter hier...

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public int getAge() {
			return age;
		}

		public void setAge(int age) {
			this.age = age;
		}

		public Person() {
		}

		public Person(int id, String name, int age) {
			this.id = id;
			this.name = name;
			this.age = age;
		}
	}
}
