package com.proj.Projekt3.dto;

import java.util.List;


public class PersonRequest {

	
	  public PersonRequest() {
	
		}
	  
    private String name;

    public PersonRequest(String name, int age, List<String> pets) {
		super();
		this.name = name;
		this.age = age;
		this.pets = pets;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public List<String> getPets() {
		return pets;
	}

	public void setPets(List<String> pets) {
		this.pets = pets;
	}

	private int age;

    private List<String> pets;

    // Getter und Setter hier...
}

