package com.proj.Projekt3.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;

@RestController
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@RequestMapping("/fahrzeuge")
public class FahrzeugController {

	private static final Logger logger = LoggerFactory
			.getLogger(FahrzeugController.class);
	private static int nextId = 1;

	public static int getNextId() {
		return nextId;
	}

	public static void setNextId(int nextId) {
		FahrzeugController.nextId = nextId;
	}
	private final List<Fahrzeug> fahrZeug = new ArrayList<>();

	@GetMapping
	public List<Fahrzeug> getFahrzeuge() {
		logger.info("fahrZeuge info get");
		return fahrZeug;
	}

	@PostMapping
	public Fahrzeug createFahrzeug(@RequestBody Fahrzeug fahrZeuge) {
		fahrZeuge.setId(nextId++);
		fahrZeug.add(fahrZeuge);
		logger.info("fahrZeug added");
		return fahrZeuge;
	}

	public static class Fahrzeug {

		private int id; // Neue ID-Eigenschaft

		@JsonProperty("marke")
		private String marke;

		@JsonProperty("baujahr")
		private int baujahr;

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getMarke() {
			return marke;
		}

		public void setMarke(String marke) {
			this.marke = marke;
		}

		public int getBaujahr() {
			return baujahr;
		}

		public void setBaujahr(int baujahr) {
			this.baujahr = baujahr;
		}

		public Fahrzeug() {

		}

		public Fahrzeug(String marke, int baujahr) {
			this.marke = marke;
			this.baujahr = baujahr;
		}

	}

}
