package com.proj.Projekt3.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;

@RestController
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@RequestMapping("/persons")
public class PersonController {

	private static final Logger logger = LoggerFactory
			.getLogger(PersonController.class);
	private static int nextId = 1;

	public static int getNextId() {
		return nextId;
	}

	public static void setNextId(int nextId) {
		PersonController.nextId = nextId;
	}

	private final List<Person> persons = new ArrayList<>();

	@GetMapping
	public List<Person> getPersons() {
		logger.info("Person info get");
		return persons;
	}

	@PostMapping
	public Person createPerson(@RequestBody Person person) {
		person.setId(nextId++);
		persons.add(person);
		logger.info("Person added");
		return person;
	}

	public static class Person {

		private int id; // Neue ID-Eigenschaft

		@JsonProperty("name")
		private String name;

		@JsonProperty("age")
		private int age;

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public int getAge() {
			return age;
		}

		public void setAge(int age) {
			this.age = age;
		}

		public Person() {
		}

		public Person(String name, int age) {
			this.name = name;
			this.age = age;
		}
	}
}
